class generator;
transaction tr;
mailbox #(transaction) g2d;
function new(input mailbox #(transaction) g2d);
this.g2d=g2d;
endfunction
task run();
#1;
tr=new();
send();
receive();
send1();
receive1();
endtask;
task send();
tr = new();
 tr.T_AWADD   = 32'd00;
   tr.T_WDATA   = 32'd100;
   tr.T_AWLEN   = 4'd0;     // 4 beats
   tr.T_AWSIZE  = 3'd2;     // 4 bytes
    tr.T_AWBURST = 2'b00;
    tr.start=1;

       g2d.put(tr);
#10;
    endtask
    task receive();
    tr = new();
     tr.T_ARADD   = 32'd00;
    tr.T_ARLEN   = 4'd0;
    tr.T_ARSIZE  = 3'd2;
    tr.T_ARBURST = 2'b00;

    #10 tr.start = 1;
    #10 tr.start = 0;
g2d.put(tr);
#10;
endtask
    task send1();
tr.T_AWADD   = 32'd00;
    tr.T_WDATA   = 32'd55;
    tr.T_AWLEN   = 4'd3;
    tr.T_AWSIZE  = 3'd2;
    tr.T_AWBURST = 2'b01;
    tr.start=1;

       g2d.put(tr);
#10;
    endtask
    task receive1();
     tr.T_ARADD   = 32'h00;
    tr.T_ARLEN   = 4'd3;
    tr.T_ARSIZE  = 3'd2;
    tr.T_ARBURST = 2'b01;

    #10 tr.start = 1;
    #10 tr.start = 0;
g2d.put(tr);
#10;
endtask


task test_overwrite();
  $display("\n===== TEST 5 : OVERWRITE =====");

  tr = new();
  tr.T_AWADD   = 32'd0;
  tr.T_WDATA   = 32'd111;
  tr.T_AWLEN   = 4'd0;
  tr.T_AWSIZE  = 3'd2;
  tr.T_AWBURST = 2'b01;
  tr.start     = 1;
  g2d.put(tr);

  #20;

  tr = new();
  tr.T_AWADD   = 32'd0;
  tr.T_WDATA   = 32'd999;
  tr.T_AWLEN   = 4'd0;
  tr.T_AWSIZE  = 3'd2;
  tr.T_AWBURST = 2'b01;
  tr.start     = 1;
  g2d.put(tr);

  #30;

  tr = new();
  tr.T_ARADD   = 32'd0;
  tr.T_ARLEN   = 4'd0;
  tr.T_ARSIZE  = 3'd2;
  tr.T_ARBURST = 2'b01;
  tr.start     = 1;
  g2d.put(tr);

  #40;
endtask



    endclass

    
